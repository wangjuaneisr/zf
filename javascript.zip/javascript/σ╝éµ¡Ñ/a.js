let tools  = {
    test : function(){
        console.log('1111')
    }
}