// isNaN 首先进行Number转化 然后与NAN对比
// console.log(Number(undefined))//NAN
//基本数据类型 number string bealoon null undefined object symbol

var a = '124a';
console.log(parseInt(true));//NAN


